#!/bin/bash

gain()
{
pip install virtualenv
cd ~/virtualenv
virtualenv simproject
source ~/virtualenv/simproject/bin/activate
pip install -r req.txt
gzin
arduin1
ardugzin
}

#gazebo install 
gzin()
{
cd ~/virtualenv/simproject
sudo apt-get update
sudo apt-get install lsb-release wget gnupg
sudo wget https://packages.osrfoundation.org/gazebo.gpg -O /usr/share/keyrings/pkgs-osrf-archive-keyring.gpg
echo "deb [arch=$(dpkg --print-architecture) signed-by=/usr/share/keyrings/pkgs-osrf-archive-keyring.gpg] http://packages.osrfoundation.org/gazebo/ubuntu-stable $(lsb_release -cs) main" | sudo tee /etc/apt/sources.list.d/gazebo-stable.list > /dev/null
sudo apt-get update
sudo apt-get install gz-garden
}

#ardupilot install
arduin1()
{
cd ~/virtualenv/simproject
sudo apt-get update
sudo apt-get install git
sudo apt-get install gitk git-gui
git clone --recurse-submodules https://github.com/ArduPilot/ardupilot.git
cd ~/virtualenv/simproject/ardupilot/Tools/environment_install
sed -i 's#-user#-src <~/virtualenv/simproject>#' install-prereqs-ubuntu.sh
cd ~/virtualenv/simproject/ardupilot
Tools/environment_install/install-prereqs-ubuntu.sh -y
## . ~/.profile
## ./waf configue 
## ./waf clean
}

#ardugazebo plugin install
ardugzin(){
cd ~/virtualenv/simproject
sudo apt update
sudo apt install libgz-sim7-dev rapidjson-dev
git clone https://github.com/ArduPilot/ardupilot_gazebo
cd ardupilot_gazebo
mkdir build && cd build
cmake .. -DCMAKE_BUILD_TYPE=RelWithDebInfo
make -j4

echo 'export GZ_SIM_SYSTEM_PLUGIN_PATH=$HOME/ardupilot_gazebo/build:${GZ_SIM_SYSTEM_PLUGIN_PATH}' >> ~/.bashrc
echo 'export GZ_SIM_RESOURCE_PATH=$HOME/ardupilot_gazebo/models:$HOME/ardupilot_gazebo/worlds:${GZ_SIM_RESOURCE_PATH}' >> ~/.bashrc
source ~/.bashrc
}

vgzardu()
{
    cd ~/virtualenv/simproject/ardupilot_gazebo/build
    export GZ_SIM_SYSTEM_PLUGIN_PATH=$HOME/virtualenv/simproject/ardupilot_gazebo/build:${GZ_SIM_SYSTEM_PLUGIN_PATH}
    export GZ_SIM_RESOURCE_PATH=$HOME/virtualenv/simproject/ardupilot_gazebo/models:$HOME/virtualenv/simproject/ardupilot_gazebo/worlds:${GZ_SIM_RESOURCE_PATH}
    gz sim -v4 -r iris_runway.sdf
}

vgzardu1()
{
    cd ~/virtualenv/simproject/ardupilot/ArduCopter
    sim_vehicle.py -v ArduCopter -f gazebo-iris --model JSON --map --console
}

vgzpyth()
{
    cd ~/virtualenv/dk
    python basic_template.py --connect 127.0.0.1:14550
}

